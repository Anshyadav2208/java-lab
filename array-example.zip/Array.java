//write a program to intialize and print the array*/
import java.util.*;
public class Array{
    public static void main(String[]args)
    {
        int size;
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter size");
        size=sc.nextInt();
        int a[]=new int[size];
        for(int i=0;i<size;i++)
        {
            a[i]=i;
            System.out.println("Array is "+a[i]);
        }
        
    }
}

//to demonstrate for each loop using array/

input java.util.*;
class Demonstration{
    public static void main(String [] args)
    {
        int []age={new int []{1,2,3};
        System.out.println(age.length);
        for(int a:age)
        {
            System.out.println(a);
            
        }
    }
}


//WAP TO CREATE A INTEGER ARRAY CALCUALTE THE SUM AND AVERAGE OF ALL THE ARRAY USING FOR EACH LOOP

input java.util.*;
class Array{
    public static void main(String[]args)
    {
        int num[]=new int[]{10,9,6,5,4,3,2,1};
        int sum=0;
        double avg=0;
        
        for
    }
}



//WAP TO CREATE A INTEGER ARRAY CALCUALTE THE SUM AND AVERAGE OF ALL THE ARRAY USING FOR EACH LOOP

import java.util.*;
 pulic class Arr{
    public static void main(String[]args)
    {
        int num[]=new int[]{10,9,6,5,4,3,2,1};
        int sum=0;
        double avg=0;
        
        for(int a:num)
        {
            sum += a;
            
        }
        System.ou.println(sum)
        avg = (double)sum;
        
    }
}