
//WAP TO CREATE A INTEGER ARRAY CALCUALTE THE SUM AND AVERAGE OF ALL THE ARRAY USING FOR EACH LOOP

import java.util.*;
 public class Arr2{
    public static void main(String[]args)
    {
        int num[]=new int[]{10};
        int sum=0;
        double avg=0;
        
        for(int a:num)
        {
            sum += a;
            
        }
        System.out.println(sum);
        avg = (double)sum;
        
    }
}