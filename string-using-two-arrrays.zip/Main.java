//comment string objects using two arrays
import java.util.Arrays;
public class A{
    public static void main(String []args)
    {
        int a[]={200,1979,1980,2002};
        String[]s={"joy","sam","Shyam"};
        System.out,println("Integer arrays is"+ Arrays to String(a));
        
    }
}
