//demonstartion of inbuilt arrays class and two string method and method overloading/


import java.util.Arrays;
public class A{
    public static void main(String []args)
    {
        int a[]={200,1979,1980,2002};
        String[]s={"joy","sam","Shyam"};
        System.out.println("Integer arrays is"+ Arrays.toString(a));
        Arrays.sort(a);
        System.out.println("sorted Int arr"+ Arrays.toString(a));
        System.out.println(" String array is"+ Arrays.toString(s));
        Arrays.sort(s);
        
    }
}